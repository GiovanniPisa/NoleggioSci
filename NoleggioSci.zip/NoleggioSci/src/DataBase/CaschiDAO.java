package DataBase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Entity.Caschi;
import Entity.Caschi.DimensioneCasco;

import Exception.DAOException;
import Exception.DBConnectionException;

public class CaschiDAO {

    public static List<Caschi> VisualizzaCatalogoCasco() throws DAOException, DBConnectionException {
        List<Caschi> caschi = new ArrayList<>();

        try {
            Connection conn = DBManager.getConnection();

            String query = "SELECT * FROM `caschi` ;";

            try {
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet result = stmt.executeQuery();

                while (result.next()) {
                    int id = result.getInt("id");
                    String disponibilità = result.getString("Disponibilita");
                    float prezzo = result.getFloat("prezzo");
                    String dimensione = result.getString("taglia");

                    DimensioneCasco dim = DimensioneCasco.valueOf(dimensione);
                    Caschi casco = new Caschi(disponibilità, prezzo, dim, id);
                    casco.set_id(id);
                    caschi.add(casco);
                }
            } catch (SQLException e) {
                throw new DAOException("Errore nella visualizzazione del catalogo!");
            } finally {
                DBManager.closeConnection();
            }

        } catch (SQLException e) {
            throw new DBConnectionException("Errore connessione database");
        }

        return caschi;
    }
    public static void aggiornaDB(int id) throws DAOException, DBConnectionException {
		 try {
	        	Connection conn = DBManager.getConnection();

	            String query = "UPDATE Caschi SET Disponibilita = 'Non Disponibile'  WHERE id = ? ;";

	            try 
	            	(PreparedStatement stmt = conn.prepareStatement(query)) {
	                    stmt.setInt(1, id);
	                
	                    stmt.executeUpdate();
	                    System.out.println("Update del Database eseguito! \n");
	            } catch (SQLException e) {
	                throw new DAOException("Errore nella visualizzazione del catalogo!");
	            } finally {
	                DBManager.closeConnection();
	            }

	        } catch (SQLException e) {
	            throw new DBConnectionException("Errore connessione database");
	        }
	}
    public static void aggiornaDB2(int id) throws DAOException, DBConnectionException {
		 try {
	        	Connection conn = DBManager.getConnection();

	            String query = "UPDATE Caschi SET Disponibilita = 'Disponibile'  WHERE id = ? ;";

	            try 
	            	(PreparedStatement stmt = conn.prepareStatement(query)) {
	                    stmt.setInt(1, id);
	                
	                    stmt.executeUpdate();
	                    System.out.println("Update del Database eseguito! \n");
	            } catch (SQLException e) {
	                throw new DAOException("Errore nella visualizzazione del catalogo!");
	            } finally {
	                DBManager.closeConnection();
	            }

	        } catch (SQLException e) {
	            throw new DBConnectionException("Errore connessione database");
	        }
	}
}