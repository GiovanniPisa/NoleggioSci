package DataBase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Entity.Clienti;
import Entity.Residenza;
import Exception.DAOException;
import Exception.DBConnectionException;

public class ResidenzaDAO {
	public static int CreateResidenza(String v, String c, String p, int nc) throws DAOException, DBConnectionException {
		 int generatedId = -1; 

        try {
        	Connection conn = DBManager.getConnection();

            String query = "INSERT INTO RESIDENZA (via, citta, provincia, numerocivico) VALUES (?, ?, ?, ?);";

            try 
            	(PreparedStatement stmt = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS)) {
                    stmt.setString(1, v);
                    stmt.setString(2, c);
                    stmt.setString(3, p);
                    stmt.setInt(4, nc);

                    stmt.executeUpdate();
                    try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            generatedId = generatedKeys.getInt(1); 
                        }
                    }
            } catch (SQLException e) {
                throw new DAOException("Errore nella visualizzazione del catalogo!");
            } finally {
                DBManager.closeConnection();
            }

        } catch (SQLException e) {
            throw new DBConnectionException("Errore connessione database");
        }
        
        return generatedId;
    }
	public static Residenza LeggiResidenza(int id) throws DAOException, DBConnectionException {
		try {
            Connection conn = DBManager.getConnection();
            
            String query = "SELECT * FROM residenza WHERE id = ?";

            try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
                preparedStatement.setInt(1, id);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                	
                    if (resultSet.next()) {
          
                        String via = resultSet.getString("via");
                        String citta = resultSet.getString("citta");
                        String provincia = resultSet.getString("provincia");
                        int numerocivico = resultSet.getInt("numerocivico");
                        int id_residenza = resultSet.getInt("id");
                        Residenza res = new Residenza (via, citta, provincia, numerocivico);
                        res.set_id_residenza(id_residenza);
                        
                        
                        
                        return  res;
                    } else {
                        throw new DAOException("REsidenza non trovata !");
                    }
                }
            } catch (SQLException e) {
                throw new DAOException("Errore nella visualizzazione del cliente!");
            } finally {
                DBManager.closeConnection();
            }
        } catch (SQLException e) {
            throw new DBConnectionException("Errore connessione database");
        }
	}
	public static void rifiutaPResidenza(int i) throws DAOException, DBConnectionException{
		try {
        	Connection conn = DBManager.getConnection();

            String query = "DELETE FROM residenza WHERE id  = ? ;";

            try 
            	(PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setInt(1, i);	                
                    stmt.executeUpdate();
                    System.out.println("Update del Database eseguito! \n");
            } catch (SQLException e) {
                throw new DAOException("Errore nella visualizzazione del catalogo!");
            } finally {
                DBManager.closeConnection();
            }

        } catch (SQLException e) {
            throw new DBConnectionException("Errore connessione database");
            
        }
	
	}
	

}
