package DataBase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Entity.Scarponi;
import Exception.DAOException;
import Exception.DBConnectionException;

public class ScarponiDAO {

    public static List<Scarponi> VisualizzaCatalogoScarponi() throws DAOException, DBConnectionException {
        List<Scarponi> scarponi = new ArrayList<>();

        try {
            Connection conn = DBManager.getConnection();

            String query = "SELECT * FROM SCARPONI ;";

            try {
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet result = stmt.executeQuery();

                while (result.next()) {
                    int id = result.getInt("id");
                    String disponibilità = result.getString("disponibilita");
                    float prezzo = result.getFloat("prezzo");
                    int misura = result.getInt("misura");

                    Scarponi scarpone = new Scarponi(disponibilità, misura, id);
                    scarpone.set_prezzoScarponi(prezzo);
                    scarpone.set_id(id);
                    scarponi.add(scarpone);
                }
            } catch (SQLException e) {
                throw new DAOException("Errore nella visualizzazione del catalogo!");
            } finally {
                DBManager.closeConnection();
            }

        } catch (SQLException e) {
            throw new DBConnectionException("Errore connessione database");
        }

        return scarponi;
    }
    public static void aggiornaDB(int id) throws DAOException, DBConnectionException {
		 try {
	        	Connection conn = DBManager.getConnection();

	            String query = "UPDATE Scarponi SET Disponibilita = 'Non Disponibile ' WHERE id = ? ;";

	            try 
	            	(PreparedStatement stmt = conn.prepareStatement(query)) {
	                    stmt.setInt(1, id);
	                
	                    stmt.executeUpdate();
	                    System.out.println("Update del Database eseguito! \n");
	            } catch (SQLException e) {
	                throw new DAOException("Errore nella visualizzazione del catalogo!");
	            } finally {
	                DBManager.closeConnection();
	            }

	        } catch (SQLException e) {
	            throw new DBConnectionException("Errore connessione database");
	        }
	}
	 public static void aggiornaDB2(int id) throws DAOException, DBConnectionException {
		 try {
	        	Connection conn = DBManager.getConnection();

	            String query = "UPDATE Scarponi SET Disponibilita = 'Disponibile ' WHERE id = ? ;";

	            try 
	            	(PreparedStatement stmt = conn.prepareStatement(query)) {
	                    stmt.setInt(1, id);
	                
	                    stmt.executeUpdate();
	                    System.out.println("Update del Database eseguito! \n");
	            } catch (SQLException e) {
	                throw new DAOException("Errore nella visualizzazione del catalogo!");
	            } finally {
	                DBManager.closeConnection();
	            }

	        } catch (SQLException e) {
	            throw new DBConnectionException("Errore connessione database");
	        }
	}
}
