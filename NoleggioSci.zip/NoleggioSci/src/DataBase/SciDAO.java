package DataBase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Entity.Sci;
import Entity.Sci.Lunghezza;
import Entity.Sci.Tipologia;
import Exception.DAOException;
import Exception.DBConnectionException;

public class SciDAO {

    public static List<Sci> VisualizzaCatalogoSci() throws DAOException, DBConnectionException {
        List<Sci> sciList = new ArrayList<>();

        try {
            Connection conn = DBManager.getConnection();

            String query = "SELECT * FROM SCI;";

            try {
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet result = stmt.executeQuery();

                while (result.next()) {
                    int id = result.getInt("id");
                    String disponibilità = result.getString("disponibilita");
                    float prezzo = result.getFloat("prezzo");
                    String lunghezza = result.getString("lunghezza");
                    String tipologia = result.getString("tipologia");

                    Lunghezza lun = Lunghezza.valueOf(lunghezza);
                    Tipologia tip = Tipologia.valueOf(tipologia);

                    Sci nuovoSci = new Sci(disponibilità, prezzo, lun, tip, id);
                    nuovoSci.set_id(id);
                    sciList.add(nuovoSci);
                }
            } catch (SQLException e) {
                throw new DAOException("Errore nella visualizzazione del catalogo!");
            } finally {
                DBManager.closeConnection();
            }

        } catch (SQLException e) {
            throw new DBConnectionException("Errore connessione database");
        }

        return sciList;
    }

	public static void aggiornaDB(int id) throws DAOException, DBConnectionException {
		 try {
	        	Connection conn = DBManager.getConnection();

	            String query = "UPDATE sci SET Disponibilita = 'Non Disponibile'  WHERE id = ? ;";

	            try 
	            	(PreparedStatement stmt = conn.prepareStatement(query)) {
	                    stmt.setInt(1, id);
	                
	                    stmt.executeUpdate();
	                    System.out.println("Update del Database eseguito! \n");
	            } catch (SQLException e) {
	                throw new DAOException("Errore nella visualizzazione del catalogo!");
	            } finally {
	                DBManager.closeConnection();
	            }

	        } catch (SQLException e) {
	            throw new DBConnectionException("Errore connessione database");
	        }
	}

	public static void aggiornaDB2(int id) throws DAOException, DBConnectionException {
		 try {
	        	Connection conn = DBManager.getConnection();

	            String query = "UPDATE sci SET Disponibilita = 'Disponibile'  WHERE id = ? ;";

	            try 
	            	(PreparedStatement stmt = conn.prepareStatement(query)) {
	                    stmt.setInt(1, id);
	                
	                    stmt.executeUpdate();
	                    System.out.println("Update del Database eseguito! \n");
	            } catch (SQLException e) {
	                throw new DAOException("Errore nella visualizzazione del catalogo!");
	            } finally {
	                DBManager.closeConnection();
	            }

	        } catch (SQLException e) {
	            throw new DBConnectionException("Errore connessione database");
	        }
	}
}