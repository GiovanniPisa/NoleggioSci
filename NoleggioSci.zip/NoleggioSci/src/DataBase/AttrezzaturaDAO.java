package DataBase;

import java.util.ArrayList;
import java.util.List;

import Entity.Attrezzatura;
import Entity.Caschi;
import Entity.Scarponi;
import Entity.Sci;
import Entity.Snowboard;
import Exception.DAOException;
import Exception.DBConnectionException;

public class AttrezzaturaDAO {
	public static List<Attrezzatura> leggiAttrezzatura(List<Integer> id) throws Exception {
		
		List<Caschi> caschilist = CaschiDAO.VisualizzaCatalogoCasco();
		List<Snowboard> snowbaordlist = SnowboardDAO.VisualizzaCatalogoSnowboard();
		List<Sci> scilist = SciDAO.VisualizzaCatalogoSci();
		List<Scarponi> scarponilist = ScarponiDAO.VisualizzaCatalogoScarponi();
		List<Attrezzatura> attrezzature= new ArrayList<>();
		
		for(int ids : id) {
		for (Sci sci : scilist) {
			
            if (sci.get_id() == ids) {
            	attrezzature.add(sci);
            }
        }

        for (Snowboard snowboard : snowbaordlist) {
            if (snowboard.get_id() == ids) {
            	attrezzature.add(snowboard);
            }
        }

        for (Scarponi scarponi : scarponilist) {
            if (scarponi.get_id() == ids) {
            	attrezzature.add(scarponi);
            }
        }

        for (Caschi casco : caschilist) {
            if (casco.get_id() == ids) {
            	attrezzature.add(casco);
            }
        }

		
		}
		return attrezzature;
	}

	public static void prenota(List<Attrezzatura> a) throws DAOException, DBConnectionException {
		for (Attrezzatura att : a) {
			 if (att instanceof Sci) {
		            SciDAO.aggiornaDB(att.get_id());
		        } else if (att instanceof Snowboard) {
		            SnowboardDAO.aggiornaDB(att.get_id());
		        } else if (att instanceof Scarponi) {
		            ScarponiDAO.aggiornaDB(att.get_id());
		        } else if (att instanceof Caschi) {
		            CaschiDAO.aggiornaDB(att.get_id());
		        } else {
		            System.out.println("L'oggetto è un'istanza di un'altra classe");
		        }
		}
		
	}

	public static void Disponibile(List<Attrezzatura> a) throws DAOException, DBConnectionException {
		for (Attrezzatura att : a) {
			 if (att instanceof Sci) {
		            SciDAO.aggiornaDB2(att.get_id());
		        } else if (att instanceof Snowboard) {
		            SnowboardDAO.aggiornaDB2(att.get_id());
		        } else if (att instanceof Scarponi) {
		            ScarponiDAO.aggiornaDB2(att.get_id());
		        } else if (att instanceof Caschi) {
		            CaschiDAO.aggiornaDB2(att.get_id());
		        } else {
		            System.out.println("L'oggetto è un'istanza di un'altra classe");
		        }
		}
	}
	

}
