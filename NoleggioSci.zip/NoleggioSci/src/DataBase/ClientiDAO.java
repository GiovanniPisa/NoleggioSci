package DataBase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Entity.Caschi;
import Entity.Clienti;
import Entity.Residenza;
import Exception.DAOException;
import Exception.DBConnectionException;

public class ClientiDAO {
	public static int createClienti(String nome, String cognome, String email, String documento,String v, String c, String p, int nc) throws DAOException, DBConnectionException {
		   int id= ResidenzaDAO.CreateResidenza(v, c, p ,nc);
		   int generatedId = -1;

        try {
        	Connection conn = DBManager.getConnection();

            String query = "INSERT INTO Clienti (nome, cognome, email, residenza, documento) VALUES (?, ?, ?, ?,?);";

            try 
            	(PreparedStatement stmt = conn.prepareStatement(query,  PreparedStatement.RETURN_GENERATED_KEYS)) {
                    stmt.setString(1, nome);
                    stmt.setString(2, cognome);
                    stmt.setString(3, email);
                    stmt.setInt(4, id);
                    stmt.setString(5, documento);

                    stmt.executeUpdate();
                    try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            generatedId = generatedKeys.getInt(1);
                        }
                    }
            } catch (SQLException e) {
                throw new DAOException("Errore nella visualizzazione del catalogo!" + e.getMessage());
            } finally {
                DBManager.closeConnection();
            }

        } catch (SQLException e) {
            throw new DBConnectionException("Errore connessione database");
        }
        return generatedId;
    }
	public static Clienti leggiCliente(int id) throws DAOException, DBConnectionException {
        try {
            Connection conn = DBManager.getConnection();
            String query = "SELECT * FROM clienti WHERE id = ?";

            try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
                preparedStatement.setInt(1, id);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
          
                        String nome = resultSet.getString("nome");
                        String cognome = resultSet.getString("cognome");
                        String email = resultSet.getString("email");
                        Integer Res = resultSet.getInt("residenza");
                        String documento = resultSet.getString("documento");
                        
                        
                        Residenza residenza= ResidenzaDAO.LeggiResidenza(Res);

                        return new Clienti( nome, cognome, email, residenza, documento);
                    } else {
                        throw new DAOException("Cliente non trovato!");
                    }
                }
            } catch (SQLException e) {
                throw new DAOException("Errore nella visualizzazione del cliente!");
            } finally {
                DBManager.closeConnection();
            }
        } catch (SQLException e) {
            throw new DBConnectionException("Errore connessione database");
        }
    }
	public static void rifiutaPclienti(int i) throws DAOException, DBConnectionException {
		try {
        	Connection conn = DBManager.getConnection();

            String query = "DELETE FROM clienti WHERE id  = ? ;";

            try 
            	(PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setInt(1, i);	                
                    stmt.executeUpdate();
                    System.out.println("Update del Database eseguito! \n");
            } catch (SQLException e) {
                throw new DAOException("Errore nella visualizzazione del catalogo!");
            } finally {
                DBManager.closeConnection();
            }

        } catch (SQLException e) {
            throw new DBConnectionException("Errore connessione database");
            
        }
	}
	

}

