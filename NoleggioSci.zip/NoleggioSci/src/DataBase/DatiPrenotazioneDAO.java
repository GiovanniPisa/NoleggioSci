package DataBase;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import Entity.Attrezzatura;
import Entity.Caschi;
import Entity.Caschi.DimensioneCasco;
import Entity.Clienti;
import Entity.DatiPrenotazione;
import Entity.Residenza;
import Exception.DAOException;
import Exception.DBConnectionException;

public class DatiPrenotazioneDAO {
	
	public static void InserisciPrenotazione(int cliente, int attrezzatura) throws DAOException, DBConnectionException {
		

        try {
        	Connection conn = DBManager.getConnection();

            String query = "INSERT INTO datiprenotazione (Cliente, Attrezzatura) VALUES (?, ?);";

            try 
            	(PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setInt(1, cliente);
                    stmt.setInt(2, attrezzatura);
                
                    stmt.executeUpdate();
            } catch (SQLException e) {
                throw new DAOException("Errore nella visualizzazione del catalogo!");
            } finally {
                DBManager.closeConnection();
            }

        } catch (SQLException e) {
            throw new DBConnectionException("Errore connessione database");
        }
    }
	
	public static List<DatiPrenotazione> VisualizzaDatiPrenotazioni() throws Throwable {
	    List<DatiPrenotazione> datiP = new ArrayList<>();

	    try (Connection conn = DBManager.getConnection()) {
	        List<Integer> idC = LeggiIdClienti(conn);

	        for (Integer idCliente : idC) {
	            Clienti cliente = ClientiDAO.leggiCliente(idCliente);
	            cliente.set_id_Cliente(idCliente);
	            
	            List<Attrezzatura> attrezzature = recuperaAttrezzature(idCliente, conn);

	            DatiPrenotazione datiPrenotazione = new DatiPrenotazione(cliente, attrezzature);
	            datiP.add(datiPrenotazione);
	        }
	    } catch (SQLException e) {
	        throw new DBConnectionException("Errore nella connessione al database", e);
	    }

	    return datiP;
	}

	public static List<Integer> LeggiIdClienti(Connection conn) throws DAOException, DBConnectionException, SQLException {
	    List<Integer> id_c = new ArrayList<>();
	    String query = "SELECT DISTINCT cliente FROM Datiprenotazione;";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(query);
	         ResultSet resultSet = preparedStatement.executeQuery()) {

	        while (resultSet.next()) {
	            int idCliente = resultSet.getInt("cliente");
	            id_c.add(idCliente);
	        }
	    } catch (SQLException e) {
	        throw new DAOException("Errore nella visualizzazione dei clienti", e);
	    }
	    
	    return id_c;
	}

	public static List<Attrezzatura> recuperaAttrezzature(int idCliente, Connection conn) throws Exception {
	    List<Integer> ids =new ArrayList<>();
	    String query = "SELECT Attrezzatura FROM Datiprenotazione WHERE cliente = ?";
	    Connection conni= DBManager.getConnection();
	    try (PreparedStatement stmt = conni.prepareStatement(query)) {
	        stmt.setInt(1, idCliente);

	        try (ResultSet result = stmt.executeQuery()) {
	            while (result.next()) {
	                int idAttrezzatura = result.getInt("Attrezzatura");
	                ids.add(idAttrezzatura);
	                }
	            return AttrezzaturaDAO.leggiAttrezzatura(ids);
	            
	            
	        } catch (SQLException e) {
	            throw new DAOException("Errore nella visualizzazione delle attrezzature", e);
	        }
	    } catch (SQLException e) {
	        throw new DBConnectionException("Errore connessione database durante il recupero delle attrezzature per il cliente con ID: " + idCliente, e);
	    }

	    
	}
	public static void accettaPrenotazione(int i) throws DAOException, DBConnectionException {
		Random random = new Random();
        
        int min = 10000;
        int max = 99999;
        int randomNumber = min + random.nextInt((max - min) + 1);
        System.out.println("Numero di prenotazione " + randomNumber +" " + "\n Cliente numero: "+i);
		  try {
	        	Connection conn = DBManager.getConnection();

	            String query = "UPDATE datiprenotazione SET numeroPrenotazione = ?, timestamp = CURRENT_TIMESTAMP  WHERE Cliente = ? ;";

	            try 
	            	(PreparedStatement stmt = conn.prepareStatement(query)) {
	                    stmt.setInt(1, randomNumber);
	                    stmt.setInt(2, i);
	                
	                    stmt.executeUpdate();
	                    System.out.println("Update del Database eseguito! \n");
	            } catch (SQLException e) {
	                throw new DAOException("Errore nella visualizzazione del catalogo!");
	            } finally {
	                DBManager.closeConnection();
	            }

	        } catch (SQLException e) {
	            throw new DBConnectionException("Errore connessione database");
	        }
		
	}
	public static void rifiutaPrenotazione(int i) throws DAOException, DBConnectionException {
		
		  try {
	        	Connection conn = DBManager.getConnection();

	            String query = "DELETE FROM datiprenotazione WHERE Cliente  = ? ;";
	            try 
	            	(PreparedStatement stmt = conn.prepareStatement(query)) {
	                    stmt.setInt(1, i);	                
	                    stmt.executeUpdate();
	                    System.out.println("Update del Database eseguito! \n");
	            } catch (SQLException e) {
	                throw new DAOException("Errore nella visualizzazione del catalogo!");
	            } finally {
	                DBManager.closeConnection();
	                ClientiDAO.rifiutaPclienti(i);
	            }

	        } catch (SQLException e) {
	            throw new DBConnectionException("Errore connessione database");
	            
	        }
		
	}

	public static void recuperadatimail(int cc, DatiPrenotazione dp) throws DAOException, DBConnectionException {
		try {
        	Connection conn = DBManager.getConnection();

            String query = "SELECT Distinct NumeroPrenotazione, timestamp FROM datiprenotazione WHERE Cliente  = ? ;";

            try 
            	(PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setInt(1, cc);	                
                    ResultSet resultSet = stmt.executeQuery() ; 
                    while (resultSet.next()) {
        	            String nump = resultSet.getString("numeroprenotazione");
        	            Timestamp timer = resultSet.getTimestamp("timestamp");
        	            dp.setNumeroPrenotazione(nump);
        	            dp.set_Timer(timer); 
        	        }
            } catch (SQLException e) {
                throw new DAOException("Errore nella visualizzazione del catalogo!");
            } finally {
                DBManager.closeConnection();
            }

        } catch (SQLException e) {
            throw new DBConnectionException("Errore connessione database");
            
        }
		
	}

	public static void restituzionepren(String np) throws DAOException, DBConnectionException {
		try {
	        	Connection conn = DBManager.getConnection();

	            String query = "UPDATE datiprenotazione SET Consegna  = 'Restituito'  WHERE NumeroPrenotazione = ? ;";

	            try 
	            	(PreparedStatement stmt = conn.prepareStatement(query)) {
	                    stmt.setString(1, np);
	                    stmt.executeUpdate();
	                    
	                    System.out.println("Update del Database eseguito! \n");
	                    
	            } catch (SQLException e) {
	                throw new DAOException("Errore nella visualizzazione del catalogo!");
	            } finally {
	                DBManager.closeConnection();
	            }

	        } catch (SQLException e) {
	            throw new DBConnectionException("Errore connessione database");
	        }
	}


	public static void prenotaazionicons() throws DAOException, DBConnectionException {
		try {
        	Connection conn = DBManager.getConnection();
        	System.out.println("\nLista Prenotazioni ritirate e non ancora restutuite:");
        	

            String query = "SELECT * FROM datiprenotazione WHERE  Consegna = 'Consegnato' ;";

            try 
            	(PreparedStatement stmt = conn.prepareStatement(query)) {                
                    ResultSet resultSet = stmt.executeQuery() ; 
                    while (resultSet.next()) {
        	            int codicep = resultSet.getInt("NumeroPrenotazione") ;
        	            int cliente = resultSet.getInt("Cliente");

        	            System.out.println(" Numero prenotazione : " + codicep + "   Codice Cliente : " + cliente );
        	            
        	            
        	        }
                    
            } catch (SQLException e) {
                throw new DAOException("Errore nella visualizzazione del catalogo!");
            } finally {
                DBManager.closeConnection();
            }

        } catch (SQLException e) {
            throw new DBConnectionException("Errore connessione database");
            
        }
		
	}
	public static void aggiornatuple(List<Integer> clienti) throws DAOException, DBConnectionException {
		for (int a : clienti) {
			System.out.println();
			Clienti c = ClientiDAO.leggiCliente(a);
			rifiutaPrenotazione(a);
			ResidenzaDAO.rifiutaPResidenza(c.get_Residenza().get_id_residenza());
			
		}
		System.out.println("\nReport completato, prenotazioni concluse eliminate dal DB.");
		
		
	}
	public static List <Integer> prenotazionirest() throws DAOException, DBConnectionException {
		List <Integer> clienti= new ArrayList<>();
		try {
			
        	Connection conn = DBManager.getConnection();
        	System.out.println("\nLista Prenotazioni ritirate e restutuite:");
        	

            String query = "SELECT DISTInCT NumeroPrenotazione, Cliente FROM datiprenotazione WHERE  Consegna = 'Restituito' ;";

            try (PreparedStatement stmt = conn.prepareStatement(query)) {                
                    ResultSet resultSet = stmt.executeQuery() ; 
                    while (resultSet.next()) {
                    	
        	            int codicep = resultSet.getInt("NumeroPrenotazione") ;
        	            int cliente = resultSet.getInt("Cliente");
        	            clienti.add(cliente);
        	            System.out.println(" Numero prenotazione : " + codicep + "   Codice Cliente : " + cliente );
        	        }
                    
            } catch (SQLException e) {
                throw new DAOException("Errore nella visualizzazione del catalogo!");
            } finally {
                DBManager.closeConnection(); 
            }
            
        } catch (SQLException e) {
            throw new DBConnectionException("Errore connessione database");
            
        }
        return clienti;
	}
	public static void DPsetconsegnato(String cp) throws DAOException, DBConnectionException {
		try {
        	Connection conn = DBManager.getConnection();

            String query = "UPDATE DatiPrenotazione SET Consegna = 'Consegnato'  WHERE numeroprenotazione = ? ;";

            try 
            	(PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setString(1, cp);
                
                    stmt.executeUpdate();
                    
                    System.out.println("Update del Database eseguito! \n");
            } catch (SQLException e) {
                throw new DAOException("Errore nella visualizzazione del catalogo!");
            } finally {
                DBManager.closeConnection();
            }

        } catch (SQLException e) {
            throw new DBConnectionException("Errore connessione database");
        }
	}
	public static void selectrest(List<Integer> ids, List <Attrezzatura> a, String cp) throws Exception {
		try {
        	Connection conn = DBManager.getConnection();

            String query = "SELECT attrezzatura FROM datiprenotazione WHERE numeroPrenotazione = ? ;";

            try 
            	(PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setString(1, cp);	
                    ResultSet resultSet = stmt.executeQuery() ; 
                    
                    while (resultSet.next()) {
        	           int att = resultSet.getInt("Attrezzatura");
        	           ids.add(att);
        	        }
            } catch (SQLException e) {
                throw new DAOException("Errore nella visualizzazione del catalogo!");
            } finally {
                DBManager.closeConnection();
            }
            a = AttrezzaturaDAO.leggiAttrezzatura(ids);
            AttrezzaturaDAO.Disponibile(a); // aggiorna db
            DatiPrenotazioneDAO.restituzionepren(cp);
            

        } catch (SQLException e) {
            throw new DBConnectionException("Errore connessione database");
        }
	}
}




