package DataBase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Entity.Snowboard;
import Exception.DAOException;
import Exception.DBConnectionException;

public class SnowboardDAO {

    public static List<Snowboard> VisualizzaCatalogoSnowboard() throws DAOException, DBConnectionException {
        List<Snowboard> snowboards = new ArrayList<>();

        try {
            Connection conn = DBManager.getConnection();

            String query = "SELECT * FROM SNOWBOARD ;";

            try {
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet result = stmt.executeQuery();

                while (result.next()) {
                    int id = result.getInt("id");
                    String disponibilità = result.getString("disponibilita");
                    float prezzo = result.getFloat("prezzo");

                    Snowboard snowboard = new Snowboard(disponibilità, prezzo, id);
                    snowboard.set_id(id);
                    snowboards.add(snowboard);
                }
            } catch (SQLException e) {
                throw new DAOException("Errore nella visualizzazione del catalogo!");
            } finally {
                DBManager.closeConnection();
            }

        } catch (SQLException e) {
            throw new DBConnectionException("Errore connessione database");
        }

        return snowboards;
    }

    public static void aggiornaDB(int id) throws DAOException, DBConnectionException {
		 try {
	        	Connection conn = DBManager.getConnection();

	            String query = "UPDATE Snowboard SET Disponibilita =' Non Disponibile'  WHERE id = ? ;";

	            try 
	            	(PreparedStatement stmt = conn.prepareStatement(query)) {
	                    stmt.setInt(1, id);
	                
	                    stmt.executeUpdate();
	                    System.out.println("Update del Database eseguito! \n");
	            } catch (SQLException e) {
	                throw new DAOException("Errore nella visualizzazione del catalogo!");
	            } finally {
	                DBManager.closeConnection();
	            }

	        } catch (SQLException e) {
	            throw new DBConnectionException("Errore connessione database");
	        }
	}

	public static void aggiornaDB2(int id) throws DAOException, DBConnectionException {
		 try {
	        	Connection conn = DBManager.getConnection();

	            String query = "UPDATE Snowboard SET Disponibilita = 'Disponibile'  WHERE id = ? ;";

	            try 
	            	(PreparedStatement stmt = conn.prepareStatement(query)) {
	                    stmt.setInt(1, id);
	                
	                    stmt.executeUpdate();
	                    System.out.println("Update del Database eseguito! \n");
	            } catch (SQLException e) {
	                throw new DAOException("Errore nella visualizzazione del catalogo!");
	            } finally {
	                DBManager.closeConnection();
	            }

	        } catch (SQLException e) {
	            throw new DBConnectionException("Errore connessione database");
	        }
	}
}