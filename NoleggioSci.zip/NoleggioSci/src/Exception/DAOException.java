package Exception;

import java.sql.SQLException;

public class DAOException extends Exception {
	public DAOException(String string, SQLException e) {}
	
	public DAOException(String msg) {
		super(msg);
	}
}
