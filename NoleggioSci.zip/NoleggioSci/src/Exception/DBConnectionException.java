package Exception;

import java.sql.SQLException;

public class DBConnectionException extends Exception {
	public DBConnectionException(String string, SQLException e) {}
	
	public DBConnectionException(String msg) {
		super(msg);
	}
}
