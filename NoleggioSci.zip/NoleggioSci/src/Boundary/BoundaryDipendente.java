package Boundary;

import java.util.ArrayList;
import java.util.List;

import DataBase.DatiPrenotazioneDAO;
import Entity.Attrezzatura;
import Entity.Clienti;
import Entity.DatiPrenotazione;

public class BoundaryDipendente {
	public static void registraconsegna(String cp) throws Throwable {
		List<DatiPrenotazione> datiP = DatiPrenotazioneDAO.VisualizzaDatiPrenotazioni();
		for( DatiPrenotazione dp : datiP) {
			DatiPrenotazioneDAO.recuperadatimail(dp.getCliente().get_id(), dp);
		}
		int control =0;
		List<Attrezzatura> att = new ArrayList<>();
		Clienti c = null;
		for (DatiPrenotazione dp : datiP) {
			if(dp.getNumeroPrenotazione().equals(cp)) {
				control = 1;
				 c = dp.getCliente();
				att = dp.getAttrezzatura();
			}	
		}
		System.out.println( c + "\nAttrezzatura prenotata: ");
		for (Attrezzatura dp : att) {
			System.out.println("codice attrezzatura " + dp.get_id() + " "+ dp.getClass() + " " );
		}
		DatiPrenotazioneDAO.DPsetconsegnato(cp);
	}
	public static void registrarestituzione(String cp) throws Throwable {
		List <Attrezzatura> a = new ArrayList<>();
		List <Integer> ids = new ArrayList<>();
		DatiPrenotazioneDAO.selectrest(ids, a, cp);

	}


}
