package Boundary;

import java.sql.Connection;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Control.GestioneNoleggio;
import DataBase.AttrezzaturaDAO;
import DataBase.ClientiDAO;
import DataBase.DBManager;
import DataBase.DatiPrenotazioneDAO;
import DataBase.ResidenzaDAO;
import Entity.Attrezzatura;
import Entity.Clienti;
import Entity.DatiPrenotazione;
import Entity.Residenza;
import Exception.DAOException;
import Exception.DBConnectionException;


public class BoundaryCliente {
	
	//private GestioneNoleggio gestioneNoleggio;
	
	  public void visualizzaCatalogo() {
	        try {
	            GestioneNoleggio gestioneNoleggio = GestioneNoleggio.getInstance();
	            List<Attrezzatura> catalogo = gestioneNoleggio.generaReportCatalogo();

	            for (Attrezzatura attrezzatura : catalogo) {
	                System.out.println(attrezzatura);
	            }
	        } catch (DAOException | DBConnectionException e) {
	            System.out.println("Errore durante la generazione del catalogo: " + e.getMessage());
	        }
	    }
	  public void RichiestaPrenotazione() throws DAOException, DBConnectionException {
		  
		  visualizzaCatalogo();
		  
		  GestioneNoleggio gestioneNoleggio = GestioneNoleggio.getInstance();
		  
          List<Attrezzatura> catalogo = gestioneNoleggio.generaReportCatalogo();
          
          List<Attrezzatura> carrello = new ArrayList<>();
          
          int scelta= 0;
          Scanner scanner = new Scanner(System.in);
          int id;
          
          int numatt=0;
          
          List<Integer> usati = new ArrayList<>();
          
          do {
        	  System.out.println("Inserisci l'identificativo dell' attrezzatura che vuoi prenotare: ");
        	  
        	  
        	  while(true)
        	  if (scanner.hasNextInt()) {
        		      id = scanner.nextInt();
        		      if(usati.contains(id)) {
        		    	  System.out.println("Attrezzatura gia Aggiunta al carrello, scegline un altra");
        		      }else break;
        		  
        		} else {
        		    System.out.println("Per favore, inserisci un numero intero valido.");
        		    scanner.next(); // Consuma il token non valido
        		}
        	 
        	  
        	  
        	  if(GestioneNoleggio.cercaOggetto(id,catalogo)== true) {
        		  usati.add(id);
        		  carrello.add(GestioneNoleggio.aggiungiOggetto(id, catalogo));
        		  numatt++;
        	  }
        	  
        	  
        	  System.out.println("Premere 0 per uscire, qualsiasi altro numero per continuare la selezione");
        	  while(true)
            	  if (scanner.hasNextInt()) {
            		      scelta = scanner.nextInt();
            		    break;
            		  
            		} else {
            		    System.out.println("Per favore, inserisci un numero intero valido.");
            		    scanner.next(); 
            		}
          }while(scelta != 0 );
          
          for (Attrezzatura attrezzatura : carrello) {
              System.out.println(attrezzatura);
          }
          if(numatt>0) {
        	  Scanner scan = new Scanner (System.in);
        	  System.out.println("Inserire dati cliente:");
        	  String nome;
        	  while (true) {
                  System.out.println("Nome:");
                  nome = scan.nextLine();

                  // Controlla se la stringa ha meno di 50 caratteri e contiene solo lettere
                  if (nome.length() < 50 && nome.matches("[a-zA-Z]+")) {
                      break;  // Esce dal ciclo se la stringa è valida
                  }

                  // Mostra un messaggio di errore se l'inserimento non è valido
                  System.out.println("Errore: il nome deve avere meno di 50 caratteri e contenere solo lettere.");
              }
        	  String cognome;
        	  while (true) {
                  System.out.println("Cognome:");
                  cognome = scan.nextLine();

                  // Controlla se la stringa ha meno di 50 caratteri e contiene solo lettere
                  if (cognome.length() < 50 && cognome.matches("[a-zA-Z]+")) {
                      break;  // Esce dal ciclo se la stringa è valida
                  }

                  // Mostra un messaggio di errore se l'inserimento non è valido
                  System.out.println("Errore: il cognome deve avere meno di 50 caratteri e contenere solo lettere.");
              }
        	  String email;
              while (true) {
                  System.out.println("Email: ");
                  email = scan.nextLine();

                  // Controlla se la stringa contiene il carattere "@"
                  if (email.contains("@")) {
                      break;  // Esce dal ciclo se la stringa è valida
                  }

                  // Mostra un messaggio di errore se l'inserimento non è valido
                  System.out.println("Errore: l'email deve contenere il carattere '@'.");
              }
        	  String documento;
        	  while (true) {
                  System.out.println("Codice documento (carta d'identità):");
                  documento = scan.nextLine();

                  // Controlla se la stringa ha esattamente 9 caratteri
                  if (documento.length() == 9) {
                      // Trasforma il codice in maiuscolo
                      documento = documento.toUpperCase();
                      break;  // Esce dal ciclo se la stringa è valida
                  }

                  // Mostra un messaggio di errore se l'inserimento non è valido
                  System.out.println("Errore: il codice deve contenere esattamente 9 caratteri.");
              }
        	  System.out.println("via: ");
        	  String via = scan.nextLine();
        	  System.out.println("citta: ");
        	  String citta = scan.nextLine();
        	  System.out.println("provincia: ");
        	  String provincia = scan.nextLine();
        	  System.out.println("NumeroCivico: ");
        	  int nc = scan.nextInt();
        	//  scan.nextLine();
        	//  int nc =31;
        	  
        	//  Residenza residenza = new Residenza(via,citta,provincia,nc);
        	//  Clienti cliente = new Clienti(nome, cognome, email, residenza, documento );
        	  
        	  int id_cliente=ClientiDAO.createClienti(nome, cognome, email, documento, via, citta, provincia, nc);
        	  for (Attrezzatura attrezzatura : carrello) {
        		  DatiPrenotazioneDAO.InserisciPrenotazione(id_cliente, attrezzatura.get_id());
        		  
        	  }
        	  System.out.println("Invio email al magazziniere.");
          }
          
	  }
	  
	  
	  public static void effettuaPagamento(int cc ) throws Exception {
		  
		  try (Connection conn = DBManager.getConnection()) {
		        

		        	
		            Clienti cliente = ClientiDAO.leggiCliente(cc);
		            cliente.set_id_Cliente(cc);
		            List<Attrezzatura> attrezzature = DatiPrenotazioneDAO.recuperaAttrezzature(cc, conn);
		            DatiPrenotazione dp = new DatiPrenotazione(cliente, attrezzature);
		            
		            
		            DatiPrenotazioneDAO.recuperadatimail(cc,dp);
		            
		            //System.out.println("\n time stamp"+ dp.get_Timer() + "\n numero prenotazione " + dp.getNumeroPrenotazione());
		            Timestamp  timestamp = dp.get_Timer();
		            
		            System.out.println("\nTimestamp non aggiornato: " + timestamp);
		            LocalDateTime localDateTime = timestamp.toLocalDateTime();
		            localDateTime = localDateTime.plusHours(6);
		            
		            timestamp = Timestamp.valueOf(localDateTime);
		            System.out.println("\nTimestamp aggiornato: " + timestamp);
		      
		            
		            Timestamp tcorrente = new Timestamp( System.currentTimeMillis() );
		            
		            if(tcorrente.before(timestamp)) {
		            	float costototale = (float) 0.0;
			            for( Attrezzatura a : attrezzature) {
			            	
			            	 costototale = costototale + a.get_prezzo();
			            }
			            System.out.println("\n \s Riepilogo Ordine \n Il costo del ordine per il cliente " + cc + " e di " + costototale + "€ "+ "\nInserimento numero carta......\n ");
			            String numeroCarta;
			            while (true) {
			                System.out.println("Inserisci il numero della carta di credito (16 cifre): ");
			                Scanner scanner = new Scanner(System.in);
							numeroCarta = scanner.nextLine();
			                if (numeroCarta.matches("\\d{16}")) {  // Verifica se sono esattamente 16 cifre
			                    break;  // Esce dal ciclo se l'input è valido
			                }
			                System.out.println("Errore: il numero della carta deve contenere esattamente 16 cifre.");
			            }
			            System.out.println("\nPagamento effettuato!	\n Invio Mail al cliente della prenotazione numero : " + dp.getNumeroPrenotazione());
		            }else {
		            	System.out.println("\n Tempo per il pagamento scaduto!!");
		            	
		            	AttrezzaturaDAO.Disponibile(attrezzature);
		            	
		            	DatiPrenotazioneDAO.rifiutaPrenotazione(cc);
		            	ResidenzaDAO.rifiutaPResidenza(cliente.get_Residenza().get_id_residenza());
		            	
		            }
		        
		    } catch (SQLException e) {
		        throw new DBConnectionException("Errore nella connessione al database", e);
		    }
	  }
}
