package Boundary;

import java.util.Scanner;

import DataBase.AttrezzaturaDAO;
import Boundary.BoundaryMagazziniere;
import DataBase.ClientiDAO;
import DataBase.DatiPrenotazioneDAO;
import DataBase.ResidenzaDAO;
import Entity.Attrezzatura;
import Entity.Clienti;
import Entity.Residenza;

public class Main {
	public static void main(String[] args) throws Throwable {
	
	 	BoundaryCliente boundaryCliente = new BoundaryCliente();
		Scanner scanner = new Scanner(System.in);
		Integer i = 0;
		
		
		/*while( i == 0 ) {
        boundaryCliente.visualizzaCatalogo();
        
        
        
       boundaryCliente.RichiestaPrenotazione();
       System.out.println("Vuoi continuare a prenotare ? (0/si 1/no)");
       i = scanner.nextInt();
       
       }*/
		
		while(i <= 5) {
			System.out.println("Scegli un azione: \n");
			System.out.println("Magazziniere: \n 1)consulta prenotazioni\n 2)genera Report");
			System.out.println("\n Dipendente: \n 3)registra consegna(codice Prenotazione richiesto) \n 4) registra restituzione(codice Prenotazione richiesto)");
			System.out.println("\n Cliente: \n 5)effettuaPagamento(Codice Cliente richiesto).");
			System.out.println("\n Esci: Inserisci un numero > 5.");
			i = scanner.nextInt();
			
			switch(i) {
			case 1: BoundaryMagazziniere.consultaPrenotazioni();
				break;
			case 2: BoundaryMagazziniere.generaReport();
				break;
			case 3: System.out.println("\nInserisci il numero Prenotazione : (numero a 5 cifre)"); 
					scanner.nextLine();
					String a = scanner.nextLine();
					BoundaryDipendente.registraconsegna(a);
					break;
					
			case 4: System.out.println("\nInserisci il numero Prenotazione : (numero a 5 cifre)"); 
					scanner.nextLine();
					String ab = scanner.nextLine();
					BoundaryDipendente.registrarestituzione(ab);
					break;
			case 5: System.out.println("\nInserisci il CODICE CLIENTE : (numero a 2 cifre)"); 
					int c = scanner.nextInt();
			      	BoundaryCliente.effettuaPagamento(c);
			      	break;
			default: System.out.println("\nUscita dal Sistema........ Arrivederci! :)"); 
			
			
			}
		}
	} 

}

