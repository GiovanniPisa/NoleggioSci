package Boundary;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import DataBase.AttrezzaturaDAO;
import DataBase.DBManager;
import DataBase.DatiPrenotazioneDAO;
import DataBase.ResidenzaDAO;
import Entity.Attrezzatura;
import Entity.Clienti;
import Entity.DatiPrenotazione;
import Exception.DAOException;
import Exception.DBConnectionException;

public class BoundaryMagazziniere {
	public static void consultaPrenotazioni() throws Throwable{
		
		List<DatiPrenotazione> datiP = DatiPrenotazioneDAO.VisualizzaDatiPrenotazioni();
		
		for( DatiPrenotazione prenotazione : datiP ) {
			  
			System.out.println("\nCliente : ");
			System.out.println(prenotazione.getCliente());
			System.out.println("\nAttrezzature : ");
			System.out.println(prenotazione.getAttrezzatura());
			Integer i;
			Scanner scanner = new Scanner(System.in);
			System.out.println("Inserisci 1 per accettare la prenotazione 2 per rifiutare: ");
			i = scanner.nextInt();
			switch (i) {
			case 1 : System.out.println("Prenotazione Accettata! Invio email di conferma al cliente numero "+ prenotazione.getCliente().get_id() +"!");
						DatiPrenotazioneDAO.accettaPrenotazione(prenotazione.getCliente().get_id());
						AttrezzaturaDAO.prenota(prenotazione.getAttrezzatura());
				break;
			case 2 : System.out.println("Prenotazione Rifiutata! :( invio rifiuto ");
						DatiPrenotazioneDAO.rifiutaPrenotazione(prenotazione.getCliente().get_id());
						ResidenzaDAO.rifiutaPResidenza(prenotazione.getCliente().get_Residenza().get_id_residenza()); // deve cancellare la prenotazione dal db e deve rimuovere anche i dati del cliente
				break;
			default : System.out.println("Prenotazione Ignorata!");
				break;
			}
				
		}
		
	}
		public static void generaReport() throws Throwable {
		
		List<Integer> clienti= DatiPrenotazioneDAO.prenotazionirest();
		DatiPrenotazioneDAO.prenotaazionicons();
		DatiPrenotazioneDAO.aggiornatuple(clienti);
		
		
				
		}

}
