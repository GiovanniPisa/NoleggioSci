package Control;

import Exception.DAOException;
import Exception.DBConnectionException;
import Exception.OperationException;

import java.util.ArrayList;
import java.util.List;
import java.util.*;


import Entity.Attrezzatura;
import Entity.Caschi;
import Entity.Scarponi;
import Entity.Sci;
import Entity.Snowboard;
import Entity.Clienti;
import Entity.Residenza;
import DataBase.CaschiDAO;
import DataBase.ScarponiDAO;
import DataBase.SciDAO;
import DataBase.SnowboardDAO;

public class GestioneNoleggio {
	private List<Attrezzatura> attrezzaturePrenotate = new ArrayList<>();	
	private static GestioneNoleggio gN = null;
	
	public static GestioneNoleggio getInstance() { 
		if (gN == null) 
			gN = new GestioneNoleggio(); 

		return gN; 
	}

    public List<Attrezzatura> generaReportCatalogo() throws DAOException, DBConnectionException {
        List<Attrezzatura> catalogo = new ArrayList<>();

       
        List<Caschi> caschi = CaschiDAO.VisualizzaCatalogoCasco();
        catalogo.addAll(caschi);

        List<Scarponi> scarponi = ScarponiDAO.VisualizzaCatalogoScarponi();
        catalogo.addAll(scarponi);

        List<Sci> sciList = SciDAO.VisualizzaCatalogoSci();
        catalogo.addAll(sciList);

        List<Snowboard> snowboards = SnowboardDAO.VisualizzaCatalogoSnowboard();
        catalogo.addAll(snowboards);

        return catalogo;
    }
    public static boolean cercaOggetto(int i, List<Attrezzatura> catalogo) {
		  for (Attrezzatura attrezzatura : catalogo) {
			  if(i == attrezzatura.get_id() && attrezzatura.get_disponibilità().equalsIgnoreCase("Disponibile") ) {
				  return true;
				 
			  }
			  
		  }
		System.out.println("Attrezzatura non disponibile");
		return false; 
	  }
	  
	  public static Attrezzatura aggiungiOggetto(int i, List<Attrezzatura> catalogo) {
		  for (Attrezzatura attrezzatura : catalogo) {
			  if(i == attrezzatura.get_id() ) {
				  return attrezzatura;
				 
			  }
			  
		  }
		return null; 
	  }
    
}