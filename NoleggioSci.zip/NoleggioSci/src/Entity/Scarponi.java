package Entity;

public class Scarponi extends Attrezzatura {
	 private int misura; 
	    private static float prezzoScarponi;
	 
	    public Scarponi(String dis, int mis, int id) {
	        super(dis, id);
	        misura = mis;
	    }
	 
	    public void set_prezzoScarponi(float p){
	    	prezzoScarponi=p;
		} 
	    @Override
	    public float get_prezzo(){
	    	return prezzoScarponi;
		} 
	    public void set_Misura(int m){
	    	misura=m;
		}
	    public int get_Misura() {
	        return misura;
	    }
	    public String toString() {
	        return "Scarponi{id=" + get_id() + ", disponibilità=" + get_disponibilità() + ", prezzo=" + get_prezzo() + ", misura=" + get_Misura() + "}";
	    }
}
