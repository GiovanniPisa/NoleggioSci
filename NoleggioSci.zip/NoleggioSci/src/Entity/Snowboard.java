package Entity;

public class Snowboard extends Attrezzatura {
	private static float prezzoSnowboard;
 
    public Snowboard(String dis, float prezzo, int id) {
        super(dis, id);
        prezzoSnowboard=prezzo;
    }
 
    public void set_prezzoSnowboard(float p){
    	prezzoSnowboard=p;
	} 
    @Override
    public float get_prezzo(){
    	return prezzoSnowboard;
	}

    public String toString() {
        return "Snowboard{id=" + get_id() + ", disponibilità=" + get_disponibilità() + ", prezzo=" + get_prezzo() + "}";
    }
}
