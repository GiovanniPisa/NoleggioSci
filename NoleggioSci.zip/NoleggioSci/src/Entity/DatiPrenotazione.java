package Entity;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;


public class DatiPrenotazione {
	private Clienti cliente;
	private List<Attrezzatura> attrezzatura;
	private String numeroPrenotazione;
	private Timestamp timer;
	private String stato_consegna;
		
	public DatiPrenotazione(Clienti c, List<Attrezzatura> l) {
		cliente=c;
		attrezzatura= new ArrayList<>(l) ;
		
	}
	public Clienti getCliente() {
		return cliente;
	}

	public void setCliente(Clienti a) {
		cliente = a;
	}

	public List<Attrezzatura> getAttrezzatura() {
		return attrezzatura;
	}

	public void setAttrezzatura(List<Attrezzatura> a) {
		attrezzatura = a;
	}
	
	public String getNumeroPrenotazione() {
		return numeroPrenotazione;
	}

	public void setNumeroPrenotazione(String a) {
		numeroPrenotazione = a;
	}
	public void set_Timer(Timestamp t) {
		timer= t;
	}
	public Timestamp get_Timer () {
		return timer;
	}
	public void set_statoc(String c) {
		stato_consegna= c;
	}
	public String get_statoc() {
		return stato_consegna;
	}
	
	

}