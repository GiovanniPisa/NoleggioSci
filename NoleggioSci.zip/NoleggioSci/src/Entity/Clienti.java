package Entity;

public class Clienti {
	 private String nome;
	    private String cognome;
	    private String email;
	    private Residenza residenza;
	    private String documento;
	    private int id_Cliente;
	 
	    public Clienti(String nome, String cognome, String email, Residenza residenza, String documento) {
	        this.nome = nome;
	        this.cognome = cognome;
	        this.email = email;
	        this.residenza = residenza;
	        this.documento = documento;
	    }
	 
	    public String get_Nome() {
	        return nome;
	    }
	    public void set_Nome(String a) {
	    	nome=a;
	    }
	 
	    public String get_Cognome() {
	        return cognome;
	    }
	    public void set_Cognome(String a) {
	    	cognome=a;
	    }
	 
	    public String get_Email() {
	        return email;
	    }
	    public void set_Email(String a) {
	    	email=a;
	    }
	 
	    public Residenza get_Residenza() {
	        return residenza;
	    }
	    public void set_Residenza(Residenza a) {
	    	residenza= a;
	    }
	 
	    public String get_Documento() {
	        return documento;
	    }
	    public void set_Documento(String a) {
	    	documento=a;
	    }
	    public void set_id_Cliente(int a) {
	    	id_Cliente=a;
	    }
	    public int get_id() {
	    	return id_Cliente;
	    }

	    @Override
	    public String toString() {
	        return "Cliente{" +
	                "nome='" + nome + '\'' +
	                ", cognome='" + cognome + '\'' +
	                ", email='" + email + '\'' +
	                ", residenza=" + residenza +
	                ", documento='" + documento + '\'' +
	                '}';
	    }

}
