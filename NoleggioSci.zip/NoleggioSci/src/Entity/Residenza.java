package Entity;

public class Residenza {
	private String via;
    private String citta;
    private String provincia;
    private int numerocivico;
    private int id_residenza;
 
    public Residenza(String v, String c, String p, int nc) {
        this.via = v;
        this.citta = c;
        this.provincia = p;
        this.numerocivico = nc;
    }
 
    public String getVia() {
        return via;
    }
   public void setVia(String a) {
	   via=a;
   }
 
    public String getCitta() {
        return citta;
    }
    public void setCItta(String a) {
    	citta=a;
    }

 
    public String getProvincia() {
        return provincia;
    }
    public void setProvincia(String a) {
    	provincia=a;
    }
    public void set_id_residenza(int a) {
    	id_residenza=a;
    }
    public int get_id_residenza() {
    	return id_residenza;
    }
    public void set_numerocivico(int a) {
    	numerocivico=a;
    }
    public int get_numerocivico() {
    	return numerocivico;
    }
    @Override
    public String toString() {
        return "Residenza{" +
                "via='" + via + '\'' +
                ", citta='" + citta + '\'' +
                ", provincia='" + provincia + '\'' +
                ", numerocivico=" + numerocivico +
                '}';
    }
}
