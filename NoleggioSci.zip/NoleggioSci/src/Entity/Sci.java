package Entity;


public class Sci extends Attrezzatura{
	public enum Lunghezza{
		CORTI,
		MEDI,
		LUNGHI;
	}
	public enum Tipologia{
		BASE,
		MEDI,
		AVANZATI;
	}
	Lunghezza lun;	
	Tipologia tip;
	private static float prezzosci;
		public Sci(String dis, float prezzo, Lunghezza L, Tipologia Tn, int id) {
			super(dis, id);
			prezzosci=prezzo;
			lun=L;
			tip=Tn;
	}
	
	public Lunghezza get_lunghezzasci() {
		return lun;
	}	
	public void set_lunghezza(Lunghezza a) {
		lun=a;
	}
	public Tipologia get_tipologia() {
		return tip;
	}
	public void set_tipologia(Tipologia a) {
		tip=a;
	}
	@Override
	public float get_prezzo() {
		return prezzosci;
	}
	public void set_prezzosci(float a ) {
		prezzosci=a;
	}
	public String toString() {
        return "Sci{id=" + get_id() + ", disponibilità=" + get_disponibilità() + ", prezzo=" + get_prezzo() + ", lunghezza=" + get_lunghezzasci() + ", tipologia=" + get_tipologia() + "}";
    }

}
