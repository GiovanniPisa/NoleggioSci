package Entity;


public class Caschi extends Attrezzatura {
	public enum DimensioneCasco{
		M,
		L,
		XL;
	}
	private static float  prezzoCasco;
	private DimensioneCasco dim;
	public Caschi(String dis, float prezzo, DimensioneCasco dime, int id) {
		super(dis, id);
		prezzoCasco=prezzo;
		dim=dime;
	}
	public void set_prezzoCasco(float a) {
		prezzoCasco = a;
	}
	@Override
	public float get_prezzo() {
		return prezzoCasco;
	}
	public DimensioneCasco get_dimensioneCasco() {
		return dim;
	}
	
	public void set_dimensioneCasco(DimensioneCasco a ) {
		dim=a;
    }
    public String toString() {
        return "Casco{id=" + get_id() + ", disponibilità=" + get_disponibilità() + ", prezzo=" + get_prezzo() + ", dimensione=" + get_dimensioneCasco() + "}";
    }

}
