package Entity;

public abstract class Attrezzatura {
	private String disponibilita;
	private int id;
	
	public Attrezzatura (String dis, int i) {
		disponibilita=dis;
		id=i;
	}
	public String get_disponibilità() {
		return disponibilita;
	}
	public void set_disponibilità(String a) {
		 disponibilita=a;
	 }
	public int get_id() {
		return id;
	}
	public void set_id( int a) {
		id=a;
	}
	public float get_prezzo(){
		return (float) 0.0;
	}
}
